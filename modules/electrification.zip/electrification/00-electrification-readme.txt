List of images:
01 - electrification.png is showing the worldwide energy production divided per
carriers (such as coal, electricity or gas) and grouped according sectors.

---
List of datasets:
02-electrification-electrificationtrends.csv is a dataset showing future
electrification trends according to different regions and scenarios.
  [model] - the model used to calculate the data.
  [scenario] - different scenarios part of the module.
  [region] - geographic area
  [variable] - sector which electrification trends and emissions % is referred
  [unit] - unit in which the data are presented (in this case %)
  [2005 : 2100] - Years
